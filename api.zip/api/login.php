<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true"); // Include this if you are using cookies or sessions
include 'DbConnect.php';

$objDb = new dbconnect();
$conn = $objDb->connect();

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case "POST":
        $user = json_decode(file_get_contents('php://input'), true);
        $email = $user['email'];
        $password = $user['password'];

        if (empty($email) || empty($password)) {
            $response = ['status' => 0, 'message' => 'Please provide both email and password.'];
            echo json_encode($response);
            exit;
        }

        $sql = "";
        switch ($user['userType']) {
            case 'candidate':
                $sql = "SELECT * FROM candidates WHERE email = :email and password = :password";
                break;
            case 'recruiter':
                $sql = "SELECT * FROM recruiters WHERE email = :email and password = :password";
                break;
            case 'dei':
                $sql = "SELECT * FROM dei WHERE email = :email and password = :password";
                break;
            case 'academia':
                $sql = "SELECT * FROM academia WHERE email = :email and password = :password";
                break;
                case 'admin':
                    $sql = "SELECT * FROM admin WHERE email = :email and password = :password";
                    break;
            default:
                $response = ['status' => 0, 'message' => 'Invalid user type.'];
                echo json_encode($response);
                exit;
        }

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $password);
        $stmt->execute();
        $userRow = $stmt->fetch(PDO::FETCH_ASSOC);


        if ($userRow) {
            $response = ['status' => 1, 'message' => 'Login successful.', 'userData' => $userRow];
            // $_SESSION['user_type'] = $userRow['admin_type'];
            $_SESSION['a_id'] = $userRow['a_id'];
        } else {
            $response = ['status' => 0, 'message' => 'Invalid credentials.'];
        }
        break;
    default:
        $response = ['status' => 0, 'message' => 'Invalid request method.'];
}

header('Content-Type: application/json');
echo json_encode($response);
?>