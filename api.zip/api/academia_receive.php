<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
include 'DbConnect.php';

$objDb = new dbconnect();
$conn = $objDb->connect();

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case "GET":
        // Fetch data from the database and store it in an array
        $sql = "SELECT * FROM academia_applications";
        $stmt = $conn->query($sql);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Return the data as a JSON response
        echo json_encode($data);
        break;
}
?>
