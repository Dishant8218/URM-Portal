<?php
header("Access-Control-Allow-Methods: *");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

include 'DbConnect.php';

$objDb = new dbConnect();
$conn = $objDb->connect();


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendEmail($recipient, $subject, $body) {

    $mail = new PHPMailer(true);

   

    try {

        // Enable SMTP debugging (0 = no debugging, 1 = errors and messages, 2 = messages only)

        $mail->SMTPDebug = 0;

        // Set mailer to use SMTP

        $mail->isSMTP();

        // Specify main and backup SMTP servers

        $mail->Host = 'smtp.gmail.com';

        // Enable SMTP authentication

        $mail->SMTPAuth = true;

        // SMTP username

        $mail->Username   = 'khatrishivang166@gmail.com';                     //SMTP username

        $mail->Password   = 'abrancfmbzkhtyby';   

        // Enable TLS encryption, `ssl` also accepted

        $mail->SMTPSecure = 'tls';

        // TCP port to connect to

        $mail->Port = 587;

   

        // Sender information

        $mail->setFrom('khatrishivang16@gmail.com', 'Team URM');

   

        // Recipient

        $mail->addAddress($recipient);

        $mail->SMTPDebug = 2;

        // Email content

        $mail->isHTML(true);

        $mail->Subject = $subject;

        $mail->Body = $body;

   

        // Send the email

        $mail->send();

        return true;

    } catch (Exception $e) {

        // Error handling if email sending fails

        error_log('Email Sending Failed: ' . $e->getMessage());

        return false;

    }

}





$method = $_SERVER['REQUEST_METHOD'];


switch ($method) {
    case "POST":
        $user = json_decode(file_get_contents('php://input'), true);
        $userType = $user['userType'];

        if ($userType === 'candidate') {
            $full_name = $user['fullname'];
            $email = $user['email'];
            $password = $user['password'];
            $confirmPassword = $user['confirmPassword'];
            $organization = $user['organization'];
            $position = $user['position'];
            $gender = $user['gender'];
            $ethnicity = $user['ethnicity'];
            $resume = $user['resume'];
            $linkedin = $user['linkedin'];

            $sql = "INSERT INTO candidates (full_name, email, password,confirmPassword, organization, position, gender, ethnicity, resume, linkedin)
            VALUES (:full_name, :email, :password,:confirmPassword, :organization, :position, :gender, :ethnicity, :resume, :linkedin)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':full_name', $full_name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $password);
            $stmt->bindParam(':confirmPassword', $confirmPassword);
            $stmt->bindParam(':organization', $organization);
            $stmt->bindParam(':position', $position);
            $stmt->bindParam(':gender', $gender);
            $stmt->bindParam(':ethnicity', $ethnicity);
            $stmt->bindParam(':resume', $resume);
            $stmt->bindParam(':linkedin', $linkedin);

            if ($stmt->execute()) {
                $response = ['status' => 1, 'message' => 'Candidate record created successfully.'];
            } else {
                $response = ['status' => 0, 'message' => 'Candidate record creation failed.'];
            }
        } elseif ($userType === 'recruiter') {
            $full_name = $user['fullname'];
            $email = $user['email'];
            $password = $user['password'];
            $confirmPassword = $user['confirmPassword'];
            $company = $user['company'];
            $industry = $user['industry'];
            $position = $user['position'];
            $website = $user['website'];
            $linkedin = $user['linkedin'];

            $sql = "INSERT INTO recruiters (full_name, email, password,confirmPassword, company, industry, position, website, linkedin)
            VALUES (:full_name, :email, :password,:confirmPassword, :company, :industry, :position, :website, :linkedin)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':full_name', $full_name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $password);
            $stmt->bindParam(':confirmPassword', $confirmPassword);
            $stmt->bindParam(':company', $company);
            $stmt->bindParam(':industry', $industry);
            $stmt->bindParam(':position', $position);
            $stmt->bindParam(':website', $website);
            $stmt->bindParam(':linkedin', $linkedin);

            if ($stmt->execute()) {
                $response = ['status' => 1, 'message' => 'Recruiter record created successfully.'];
            } else {
                $response = ['status' => 0, 'message' => 'Recruiter record creation failed.'];
            }
        }elseif ($userType === 'dei') {
            $full_name = $user['fullname'];
            $email = $user['email'];
            $password = $user['password'];
            $confirmPassword = $user['confirmPassword'];
            $organization = $user['organization'];
            $position = $user['position'];
            $contact = $user['contact'];

            $sql = "INSERT INTO dei (full_name, email, password,confirmPassword, organization, position, contact)
            VALUES (:full_name, :email, :password,:confirmPassword, :organization, :position, :contact)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':full_name', $full_name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $password);
            $stmt->bindParam(':confirmPassword', $confirmPassword);
            $stmt->bindParam(':organization', $organization);
            $stmt->bindParam(':position', $position);
            $stmt->bindParam(':contact', $contact);

            if ($stmt->execute()) {
                $response = ['status' => 1, 'message' => 'Recruiter record created successfully.'];
            } else {
                $response = ['status' => 0, 'message' => 'Recruiter record creation failed.'];
            }
        } elseif ($userType === 'academia') {
            $full_name = $user['fullname'];
            $email = $user['email'];
            $password = $user['password'];
            $confirmPassword = $user['confirmPassword'];
            $university = $user['university'];
            $department = $user['department'];
            $position = $user['position'];
            $researchInterest = $user['researchInterest'];
            $linkedin = $user['linkedin'];

            $sql = "INSERT INTO academia (full_name, email, password,confirmPassword, university, department, position, researchInterest, linkedin )
            VALUES (:full_name, :email, :password,:confirmPassword, :university, :department, :position, :researchInterest, :linkedin)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':full_name', $full_name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $password);
            $stmt->bindParam(':confirmPassword', $confirmPassword);
            $stmt->bindParam(':university', $university);
            $stmt->bindParam(':department', $department);
            $stmt->bindParam(':position', $position);
            $stmt->bindParam(':researchInterest', $researchInterest);
            $stmt->bindParam(':linkedin', $linkedin);
            
            if ($stmt->execute()) {
                $response = ['status' => 1, 'message' => 'Recruiter record created successfully.'];
            } else {
                $response = ['status' => 0, 'message' => 'Recruiter record creation failed.'];
            }
        } 
        
        elseif ($userType === 'admin') {
            $full_name = $user['fullname'];
            $email = $user['email'];
            $password = $user['password'];

            $sql = "INSERT INTO admin (full_name, email, password)
            VALUES (:full_name, :email, :password, )";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':full_name', $full_name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $password);
            
            if ($stmt->execute()) {
                $response = ['status' => 1, 'message' => 'Recruiter record created successfully.'];
            } else {
                $response = ['status' => 0, 'message' => 'Recruiter record creation failed.'];
            }
        }
        
        
        
        elseif ($userType === 'academia_job') {
            $jobTitle = $user['jobTitle'];
            $courseName = $user['courseName'];
            $courseDuration = $user['courseDuration'];
            $jobDescription = $user['jobDescription'];
            $requiredQualifications = $user['requiredQualifications'];











            $sql = "INSERT INTO job (title, description, course_name, course_duration, required_qualifications )
            VALUES (:jobTitle, :courseName, :courseDuration, :jobDescription, :requiredQualifications)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':jobTitle', $jobTitle);
            $stmt->bindParam(':courseName', $courseName);
            $stmt->bindParam(':courseDuration', $courseDuration);
            $stmt->bindParam(':jobDescription', $jobDescription);
            $stmt->bindParam(':requiredQualifications', $requiredQualifications);
            
            if ($stmt->execute()) {
                $response = ['status' => 1, 'message' => 'Recruiter record created successfully.'];
            } else {
                $response = ['status' => 0, 'message' => 'Recruiter record creation failed.'];
            }
        } elseif ($userType === 'recruiter_job') {
            $jobTitle = $user['jobTitle'];
            $companyName = $user['companyName'];
            $location = $user['location'];
            $jobType = $user['jobType'];
            $description = $user['description'];

            $sql = "INSERT INTO recruiter_jobs (title, description, company_name, location, jobtype )
            VALUES (:jobTitle, :description, :companyName, :location, :jobType)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':jobTitle', $jobTitle);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':companyName', $companyName);
            $stmt->bindParam(':location', $location);
            $stmt->bindParam(':jobType', $jobType);
            
            if ($stmt->execute()) {
                $response = ['status' => 1, 'message' => 'Recruiter record created successfully.'];
            } else {
                $response = ['status' => 0, 'message' => 'Recruiter record creation failed.'];
            }
        } 
        else {
            $response = ['status' => 0, 'message' => 'Invalid user type.'];
        }
        break;
    case "GET":
      
            $sql = "SELECT title,description FROM job";
           
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
            // echo json_encode($jobs);
            $response = json_encode($jobs);
        
        break;
    default:
        $response = ['status' => 0, 'message' => 'Invalid request method.'];
}

header('Content-Type: application/json');
echo json_encode($response);
?>