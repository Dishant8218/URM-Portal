<?php
include 'DbConnect.php';
//Import PHPMailer classes into the global namespace

//These must be at the top of your script, not inside a function

use PHPMailer\PHPMailer\PHPMailer;

use PHPMailer\PHPMailer\SMTP;

use PHPMailer\PHPMailer\Exception;

 

error_reporting(E_ALL);

ini_set('display_errors',1);

 

header("Access-Control-Allow-Origin: *");

header("Access-Control-Allow-Headers: Content-Type, Authorization ");

header("Access-Control-Allow-Methods:  GET, POST, OPTIONS");

//Load Composer's autoloader

require 'vendor/autoload.php';

 

//Create an instance; passing `true` enables exceptions

$mail = new PHPMailer(true);

 

$postdata = file_get_contents("php://input");

 

if(isset($postdata) && !empty($postdata)){

    $request = json_decode($postdata);

    $email = $request->email;

}

 

try {

    //Server settings

    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output

    $mail->isSMTP();                                            //Send using SMTP

    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through

    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication

    $mail->Username   = 'khatrishivang166@gmail.com';                     //SMTP username

    $mail->Password   = 'abrancfmbzkhtyby';                               //SMTP password

    $mail->SMTPSecure = 'ssl';            //Enable implicit TLS encryption

    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

 

    //Recipients

    $mail->setFrom('khatrishivang166@gmail.com', 'URM Team');

    $mail->addAddress($email);     //Add a recipient

    // $mail->addAddress('hellyshukla26@gmail.com');               //Name is optional

    $mail->addReplyTo('khatrishivang166@gmail.com', 'URM - Reply');

    // $mail->addCC('cc@example.com');

    // $mail->addBCC('bcc@example.com');

 

    //Attachments

    // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments

    // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

 

    //Content

    $mail->isHTML(true);                                  //Set email format to HTML

    $mail->Subject = 'Welcome to URM Portal!';

    $mail->Body    = 'Welcome! You have successfully registered to URM Portal!';

    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

 

    $mail->send();

    echo 'Message has been sent';

} catch (Exception $e) {

    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";

}