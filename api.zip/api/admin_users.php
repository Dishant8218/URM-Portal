<?php
include 'DbConnect.php';

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

try {
    // Create a new instance of DbConnect
    $db = new DbConnect();
    $conn = $db->connect();

    if ($conn) {
        // Fetch Candidates
        $candidatesStmt = $conn->prepare("SELECT full_name, email, organization FROM candidates ");
        $candidatesStmt->execute();
        $candidates = $candidatesStmt->fetchAll(PDO::FETCH_ASSOC);
        // Fetch Recruiters
        $recruitersStmt = $conn->prepare("SELECT full_name, email, company FROM recruiters ");
        $recruitersStmt->execute();
        $recruiters = $recruitersStmt->fetchAll(PDO::FETCH_ASSOC);
        // Fetch Academia
        $academiaStmt = $conn->prepare("SELECT full_name, email, university FROM academia ");
        $academiaStmt->execute();
        $academia = $academiaStmt->fetchAll(PDO::FETCH_ASSOC);
        // Fetch DEI Officers
        $deiStmt = $conn->prepare("SELECT full_name, email,organization FROM dei");
        $deiStmt->execute();
        $dei = $deiStmt->fetchAll(PDO::FETCH_ASSOC);
        // Package the data into a single JSON object
        $result = [
            'candidates' => $candidates,
            'recruiters' => $recruiters,
            'academia' => $academia,
            'dei' => $dei
        ];

        // Send the result back as JSON
        echo json_encode($result);

    } else {
        echo json_encode(['error' => 'Could not connect to the database']);
    }
} catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
}
?>
