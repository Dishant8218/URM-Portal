<?php
header("Access-Control-Allow-Methods: *");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

include 'DbConnect.php';

$objDb = new dbConnect();
$conn = $objDb->connect();

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case "GET":
      
            $sql = "SELECT title,description FROM recruiter_jobs";
           
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
            // echo json_encode($jobs);
            $response = json_encode($jobs);
        
        break;
    default:
        $response = ['status' => 0, 'message' => 'Invalid request method.'];
}

header('Content-Type: application/json');
echo json_encode($response);
?>