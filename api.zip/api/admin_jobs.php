<?php
include 'DbConnect.php';

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

try {
    // Create a new instance of DbConnect
    $db = new DbConnect();
    $conn = $db->connect();

    if ($conn) {
       
        // Fetch Recruiters
        $recruitersStmt = $conn->prepare("SELECT title, company_name, location, jobtype, description FROM recruiter_jobs ");
        $recruitersStmt->execute();
        $recruiters = $recruitersStmt->fetchAll(PDO::FETCH_ASSOC);
        // Fetch Academia
        $academiaStmt = $conn->prepare("SELECT title, description , course_name, course_duration, required_qualifications FROM job ");
        $academiaStmt->execute();
        $academia = $academiaStmt->fetchAll(PDO::FETCH_ASSOC);
        
       
        // Package the data into a single JSON object
        $result = [
        
            'recruiters' => $recruiters,
            'academia' => $academia,
           
        ];

        // Send the result back as JSON
        echo json_encode($result);

    } else {
        echo json_encode(['error' => 'Could not connect to the database']);
    }
} catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
}
?>
