<?php
header('Content-Type: application/json');


$validUsername = "admin";
$validPassword = "admin123";


$data = json_decode(file_get_contents('php://input'), true);

// Check if the username and password match the valid credentials
if (isset($data['username']) && isset($data['password']) && $data['username'] === $validUsername && $data['password'] === $validPassword) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid username or password']);
}
?>
