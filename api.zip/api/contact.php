<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");  // You might need this to deal with CORS issues if your frontend and backend are hosted on different domains.
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With");

include 'DbConnect.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from POST request
$data = json_decode(file_get_contents("php://input"));

if(isset($data->name) && isset($data->email) && isset($data->message)) {

    $name = mysqli_real_escape_string($conn, $data->name);
    $email = mysqli_real_escape_string($conn, $data->email);
    $message = mysqli_real_escape_string($conn, $data->message);

    $query = "INSERT INTO contact_form (name, email, message) VALUES ('$name', '$email', '$message')";

    if($conn->query($query) === TRUE) {
        echo json_encode(["message" => "Message sent successfully."]);
    } else {
        echo json_encode(["message" => "Error: " . $conn->error]);
    }
} else {
    echo json_encode(["message" => "Invalid input."]);
}

$conn->close();
?>
