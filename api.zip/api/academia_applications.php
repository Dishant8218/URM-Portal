<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

include 'DbConnect.php';

$objDb = new DbConnect();
$conn = $objDb->connect(); // Corrected typo "objD" to "objDb"

$method = $_SERVER['REQUEST_METHOD']; // Corrected typo {'REQUEST_METHOD'} to ['REQUEST_METHOD']

switch ($method) {
    case "POST":
        // Get the raw POST data and decode it as JSON
        $postData = json_decode(file_get_contents('php://input'), true);

        // Check if the required fields are present in the data
        if (
            isset($postData['name']) &&
            isset($postData['email']) &&
            isset($postData['phone']) &&
            isset($postData['position']) &&
            isset($postData['message'])
        ) {
            $name = $postData['name'];
            $email = $postData['email'];
            $phone = $postData['phone'];
            $position = $postData['position'];
            $message = $postData['message'];

            $sql = "INSERT INTO academia_applications (name, email, phone, position, message)
            VALUES (:name, :email, :phone, :position, :message)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':phone', $phone);
            $stmt->bindParam(':position', $position);
            $stmt->bindParam(':message', $message);

            if ($stmt->execute()) {
                $response = ['status' => 1, 'message' => 'Record created successfully.'];
            } else {
                $response = ['status' => 0, 'message' => 'Failure.'];
            }
        } 
        else {
            $response = ['status' => 0, 'message' => 'Required fields are missing.'];
        }
        break;
    case "GET":
           
            $sql = "SELECT position, count(*) as apps FROM academia_applications GROUP BY position;";
         
                $stmt = $conn->prepare($sql);
                $stmt->execute();
                $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                // echo json_encode($jobs);
                $response = json_encode($jobs);
            
            break;
    default:
            $response = ['status' => 0, 'message' => 'Invalid request method.'];
}

header('Content-Type: application/json');
echo json_encode($response);
?>
