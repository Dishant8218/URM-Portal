<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

include 'DbConnect.php';

$objDb = new DbConnect();
$conn = $objDb->connect(); // Corrected typo "objD" to "objDb"

$method = $_SERVER['REQUEST_METHOD']; // Corrected typo {'REQUEST_METHOD'} to ['REQUEST_METHOD']

switch ($method) {
        case "GET":
           
                $stmt_acad = $conn->prepare("SELECT count(*) as count FROM academia ;");
                $stmt_acad->execute();
                $acad = $stmt_acad->fetchAll(PDO::FETCH_ASSOC);
                $stmt_cand = $conn->prepare("SELECT count(*) as count FROM candidates ;");
                $stmt_cand->execute();
                $cand = $stmt_cand->fetchAll(PDO::FETCH_ASSOC);
                $stmt_dei = $conn->prepare("SELECT count(*) as count FROM dei ;");
                $stmt_dei->execute();
                $dei = $stmt_dei->fetchAll(PDO::FETCH_ASSOC);
                $stmt_rec = $conn->prepare("SELECT count(*) as count FROM recruiters ;");
                $stmt_rec->execute();
                $rec = $stmt_rec->fetchAll(PDO::FETCH_ASSOC);
                $rres = array(
                    "user" => "recruiters",
                    "count" => $rec[0]["count"]
                );
                $ares = array(
                    "user" => "academia",
                    "count" => $acad[0]["count"]
                );
                $dres = array(
                    "user" => "dei",
                    "count" => $dei[0]["count"]
                );
                $cres = array(
                    "user" => "urm_candidates",
                    "count" => $cand[0]["count"]
                );
                
                $response = json_encode([$rres,$ares,$dres,$cres]);
            break;
        default:
            $response = ['status' => 0, 'message' => 'Invalid request method.'];
}

header('Content-Type: application/json');
echo json_encode($response);
?>
