<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");


// Connect to the MySQL server (update the credentials accordingly)
include 'DbConnect.php';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the form data
    $full_name = $_POST["fullname"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $organization = $_POST["organization"];
    $position = $_POST["position"];
    $gender = $_POST["gender"];
    $ethnicity = $_POST["ethnicity"];
    $resume = $_POST["resume"];
    $linkedin = $_POST["linkedin"];

    // Insert the data into the database
    $sql = "INSERT INTO candidates (full_name, email, password, organization, position, gender, ethnicity, resume, linkedin)
            VALUES ('$full_name', '$email', '$password', '$organization', '$position', '$gender', '$ethnicity', '$resume', '$linkedin')";

    if ($conn->query($sql) === TRUE) {
        echo "Candidate registered successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>