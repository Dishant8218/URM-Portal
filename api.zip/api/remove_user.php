<?php
include 'DbConnect.php';

$email = $_GET['email'];
$type = $_GET['type'];
$table = '';

// Determine the correct table based on the type parameter
switch ($type) {
    case 'candidates':
        $table = 'candidates';
        break;
    case 'recruiters':
        $table = 'recruiters';
        break;
    case 'academia':
        $table = 'academia';
        break;
    case 'dei':
        $table = 'dei';
        break;
}

$response = ['success' => false];

if ($table) {
    // Create a new instance of DbConnect
    $db = new DbConnect();
    $conn = $db->connect();

    // Prepare and execute the delete statement
    $stmt = $conn->prepare("DELETE FROM $table WHERE email = :email");
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    if ($stmt->execute()) {
        $response['success'] = true;
    } else {
        $response['error'] = 'Failed to delete the user';
    }
} else {
    $response['error'] = 'Invalid user type';
}

echo json_encode($response);
?>
